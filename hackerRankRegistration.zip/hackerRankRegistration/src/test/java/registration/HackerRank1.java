package registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class HackerRank1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver;
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("https://www.hackerrank.com/auth/signup");
		
		driver.findElement(By.id("input-1")).sendKeys("Pallavi Prajwal");
		driver.findElement(By.id("input-2")).sendKeys("pallavi.prajwal@gmail.com");
		driver.findElement(By.id("input-3")).sendKeys("Pallavi98");
		driver.findElement(By.name("tos_accepted")).click();
		driver.findElement(By.xpath("//*[@id=\"tab-1-content-0\"]/div[1]/form/div[5]/button")).click();


		driver.quit();

	}

}
